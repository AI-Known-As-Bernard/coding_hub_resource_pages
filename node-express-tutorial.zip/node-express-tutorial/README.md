# Node.js & Express, from an Empty Folder

A static, self-paced tutorial site. No build step, no server, no dependencies.

## Run it

Open `index.html` in a modern browser (double-click works). Or serve the folder
with any static server, e.g. `npx serve .`

Fonts load from Google Fonts when online and fall back to system fonts offline.
The StackBlitz buttons need an internet connection; everything else works offline.

## Files

- `index.html` – all 16 lessons, plus playground example sources at the bottom
  (`<script type="text/plain" id="preset-NAME-cjs|esm">`)
- `css/styles.css` – layout, typography, code theme, light/dark mode
- `js/highlight.js` – small syntax highlighter (JS, JSON, shell, .env)
- `js/mini-express.js` – in-browser simulation of Express 4 and 5 behavior
- `js/playground.js` – editor, request client, terminal, StackBlitz handoff
- `js/main.js` – code-style switch, copy buttons, tabs, navigation, checklist

## Editing content

- Code blocks: `<pre class="code" data-lang="js|json|bash|env|text|out" data-file="label">`
- Parallel Express 4 / 5 code: wrap two `<div class="variant" data-module="cjs|esm">`
  in a `<div class="variants">`; the tabs are added automatically.
- Blocks with `data-project="full"` are bundled into the "Open the full project
  in StackBlitz" button.
- Add a playground example: add both preset `<script>` blocks and an entry in
  `PRESETS` in `js/playground.js`.
